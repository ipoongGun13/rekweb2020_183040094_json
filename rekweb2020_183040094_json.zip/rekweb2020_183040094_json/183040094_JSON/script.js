let mahasiswa = {
    nama: "Shandika Galih",
    nrp: "030403023",
    email: "sandhikagalih@unpas.ac.id"
}

console.log(JSON.stringify(mahasiswa));